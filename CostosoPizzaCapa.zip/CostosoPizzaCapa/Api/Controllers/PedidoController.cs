using CostosoPizza.Model;
using CostosoPizza.Services;
using Microsoft.AspNetCore.Mvc;
using System;

namespace CostosoPizza.Controllers
{
    [ApiController]
    [Route("[controller]")]
    public class PedidoController : ControllerBase
    {
        private readonly PedidoService _pedidoService;

        public PedidoController(PedidoService pedidoService)
        {
            _pedidoService = pedidoService ?? throw new ArgumentNullException(nameof(pedidoService));
        }

        // GET by Id action
        [HttpGet("{id}")]
        public ActionResult<Pedido> GetPedido(int id)
        {
            var pedido = _pedidoService.ObtenerPedidoPorId(id);

            if (pedido == null)
                return NotFound(new { Mensaje = "Pedido no encontrado" }); ;

            return Ok(pedido);
        }

        // POST para crear un nuevo pedido
        [HttpPost("create")]
        public IActionResult CreatePedido([FromBody] PedidoCreateModel pedidoCreateModel)
        {
            // Asumiendo que la propiedad Id se utiliza para obtener el PedidoId
            int pedidoId = pedidoCreateModel.Id;

            // Llama al método Add de tu servicio, ajusta según tu implementación
            _pedidoService.Add(new Pedido { Id = pedidoId, Pizzas = pedidoCreateModel.Pizzas, Usuario = pedidoCreateModel.Usuario });

            return Ok(new { PedidoId = pedidoId, Mensaje = "Pedido creado exitosamente" });
        }
    }
}
