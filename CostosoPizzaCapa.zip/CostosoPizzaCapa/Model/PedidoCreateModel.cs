namespace CostosoPizza.Model;

public class PedidoCreateModel
{
    public int Id { get; set;}
    public List<Pizza>? Pizzas { get; set; }
    public Usuario? Usuario { get; set; }
}
