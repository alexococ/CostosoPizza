namespace CostosoPizza.Model;

public class Usuario
{
    public int Id { get; set; }
    public string? NombreCompleto { get; set; }
    public string? Direccion { get; set; }


}