﻿using CostosoPizza.Model;
using CostosoPizza.Data;
using System.Collections.Generic;

namespace CostosoPizza.Services
{
    public class PizzaService
    {
        private readonly PizzaRepository _pizzaRepository;

        public PizzaService(PizzaRepository pizzaRepository)
        {
            _pizzaRepository = pizzaRepository;
        }

        public List<Pizza> GetAll() => _pizzaRepository.GetAll();

        public Pizza Get(int id) => _pizzaRepository.Get(id);

        public void Add(Pizza pizza) => _pizzaRepository.Add(pizza);

        public void Delete(int id) => _pizzaRepository.Delete(id);

        public void Update(Pizza pizza) => _pizzaRepository.Update(pizza);
    }
}
