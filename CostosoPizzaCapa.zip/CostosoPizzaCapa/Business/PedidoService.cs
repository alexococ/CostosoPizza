using CostosoPizza.Model;
using CostosoPizza.Data;
using System.Collections.Generic;

namespace CostosoPizza.Services
{
    public class PedidoService
    {

        private List<Pedido> _pedidos = new List<Pedido>();  // Esto es un ejemplo, deberías usar tu propia fuente de datos

        public Pedido ObtenerPorId(int id)
        {
            return _pedidoRepository.Get(id);
        }
        private readonly PedidoRepository _pedidoRepository;

        public PedidoService(PedidoRepository pedidoRepository)
        {
            _pedidoRepository = pedidoRepository ?? throw new ArgumentNullException(nameof(pedidoRepository));
        }

        public void Add(Pedido pedido) => _pedidoRepository.Add(pedido);

        public Pedido ObtenerPedidoPorId(int id)
        {
            var pedidoEncontrado = _pedidoRepository.ObtenerPorId(id);
            return pedidoEncontrado;
        }

        public void AddPizzas(int pedidoId, List<Pizza> pizzas)
        {
            var pedido = _pedidoRepository.Get(pedidoId);
            if (pedido != null)
            {
                pedido.Pizzas.AddRange(pizzas);
                pedido.Precio = pedido.Pizzas.Sum(p => p.Price);

                // No es necesario proporcionar un usuario aquí

                _pedidoRepository.Update(pedido);
            }
        }
    }
}



