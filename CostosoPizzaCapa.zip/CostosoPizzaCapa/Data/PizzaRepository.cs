﻿using CostosoPizza.Model;
using System.Collections.Generic;
using System.Linq;

namespace CostosoPizza.Data;

public class PizzaRepository
{

    private List<Pizza> Pizzas { get; set; } = new List<Pizza>();

        public List<Pizza> GetAll() => Pizzas;

    private  int nextId = 3;

    public PizzaRepository()
    {


        Pizzas = new List<Pizza>
        {
            new Pizza
            {
                Id = 1,
                Name = "Classic Italian",
                IsGlutenFree = false,
                Ingredientes = new List<Ingrediente>
                {
                    new Ingrediente { Id= 1, Nombre = "Tomate", Precio = 2 },
                    new Ingrediente { Id= 2, Nombre = "Queso", Precio = 3 },
                }
            },
            new Pizza
            {
                Id = 2,
                Name = "Veggie",
                IsGlutenFree = true,
                Ingredientes = new List<Ingrediente>
                {
                    new Ingrediente { Id= 1, Nombre = "Tomate", Precio = 2 },
                    new Ingrediente { Id= 2, Nombre = "Queso", Precio = 3 },
                    new Ingrediente { Id= 3, Nombre = "Verduras", Precio = 1 },
                    
                }
            }

        };
    }


    public  Pizza? Get(int id) => Pizzas.FirstOrDefault(p => p.Id == id);

    public  void Add(Pizza pizza)
    {
        pizza.Id = nextId++;
        Pizzas.Add(pizza);
    }

    public  void Delete(int id)
    {
        var pizza = Get(id);
        if (pizza is null)
            return;

        Pizzas.Remove(pizza);
    }

    public  void Update(Pizza pizza)
    {
        var index = Pizzas.FindIndex(p => p.Id == pizza.Id);
        if (index == -1)
            return;

        Pizzas[index] = pizza;
    }
}
