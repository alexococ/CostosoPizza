using CostosoPizza.Model;
using System.Collections.Generic;
using System.Linq;

namespace CostosoPizza.Data
{
    public interface IPedidoRepository
    {
        Pedido? ObtenerPorId(int id);
        void Add(Pedido pedido);
        void Update(Pedido pedido);
        Pedido? Get(int id);
    }

    public class PedidoRepository : IPedidoRepository
    {
        private List<Pedido> Pedidos { get; set; } = new List<Pedido>();
        private int nextId = 1;

        public Pedido? ObtenerPorId(int id) => Pedidos.FirstOrDefault(p => p.Id == id);

        public void Add(Pedido pedido)
        {
            pedido.Id = nextId++;
            Pedidos.Add(pedido);
        }

        public void Update(Pedido pedido)
        {
            var index = Pedidos.FindIndex(p => p.Id == pedido.Id);
            if (index == -1)
                return;

            Pedidos[index] = pedido;
        }

        public Pedido? Get(int id) => Pedidos.FirstOrDefault(p => p.Id == id);
    }
}